package com.gcp.assignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BasicDetailsMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BasicDetailsMsApplication.class, args);
	}

}
