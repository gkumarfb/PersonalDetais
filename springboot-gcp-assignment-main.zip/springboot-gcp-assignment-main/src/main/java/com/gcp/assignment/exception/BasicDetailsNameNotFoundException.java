package com.gcp.assignment.exception;

public class BasicDetailsNameNotFoundException extends Exception{

	public BasicDetailsNameNotFoundException(String message) {
		super(message);
	}
}
