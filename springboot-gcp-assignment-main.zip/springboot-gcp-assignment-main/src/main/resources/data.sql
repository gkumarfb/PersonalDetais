insert into basic_detail (ID,PARTNERKEY,FIRST_NAME,LAST_NAME,AGE,DOB) 
values(101,'KEY123','Peter','Hobbs',40,'1983-12-20');
insert into basic_detail (ID,PARTNERKEY,FIRST_NAME,LAST_NAME,AGE,DOB) 
values(102,'KEY124','Bill','Thomas',30,'1993-10-15');
insert into basic_detail (ID,PARTNERKEY,FIRST_NAME,LAST_NAME,AGE,DOB) 
values(103,'KEY125','Tom','Brooks',35,'1988-05-09');