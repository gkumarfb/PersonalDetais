package com.gcp.assignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BasicDetailsMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
